/**********************************************************************
 * File:        const.h
 * Description: Defintions of constants used by Cube
 * Author:    Ahmad Abdulkader
 * Created:   2007
 *
 * (C) Copyright 2008, Google Inc.
 ** Licensed under the Apache License, Version 2.0 (the "License");
 ** you may not use this file except in compliance with the License.
 ** You may obtain a copy of the License at
 ** http://www.apache.org/licenses/LICENSE-2.0
 ** Unless required by applicable law or agreed to in writing, software
 ** distributed under the License is distributed on an "AS IS" BASIS,
 ** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 ** See the License for the specific language governing permissions and
 ** limitations under the License.
 *
 **********************************************************************/

#ifndef CUBE_CONST_H
#define CUBE_CONST_H

// Scale used to normalize a log-prob to a cost
#define PROB2COST_SCALE   4096.0
// Maximum possible cost (-log prob of MIN_PROB)
#define MIN_PROB_COST     65536
// Probability corresponding to the max cost MIN_PROB_COST
#define MIN_PROB          0.000000113
// Worst possible cost (returned on failure)
#define WORST_COST        0x40000
// Oversegmentation hysteresis thresholds
#define HIST_WND_RATIO    0.1f
#define SEG_PT_WND_RATIO  0.1f

#ifdef _WIN32
#ifdef __GNUC__
#include <climits>
#endif
#endif

#endif  // CUBE_CONST_H
